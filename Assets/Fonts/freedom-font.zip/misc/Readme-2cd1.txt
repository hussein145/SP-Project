FREEDOM 100% FREE FONT FOR COMMERCIAL USES
--------------------------------------------------------------------------------------

CREATED BY : HAMZAXDESIGN
deviantART     : HXDes.deviantart.com
fb Page            : fb.com/HXDes

FOR HELP CONTACT ME ON FB :

FB.COM/HAMZAXDESIGN

Stay tuned with updates :)  